SC@16 logs — Tyler's half (MATH-500, window 256, budget 16), for SC@32 merge
============================================================================
Config: SC@16 = PeerConf cell, all early-stop off (SEATS=MAX_TRACES=16,
PROBE_EVERY=0, CONSENSUS=2.0, BAR_KEEP_TOP=100, LOOP=off, margin cert neutralised).
16 traces per question run to completion, plain vote. Same model/sampling/window
as the DeepConf full-500 run.

Per-question voting is in each log under "=== Voting Results Summary ===" /
"=== Detailed Voting Results ===" and the "Qxxx done | gt=... | majority:..." line.

COVERAGE (Tyler): Q0-249 complete (250/250), plus Mofe's 3 budget-cut gaps.
  Q0-112    -> math500_w256_sc/sc_shard{0..3}.log        (4-shard run)
  Q113-124  -> math500_w256_sc_gaps/sc_q{113..124}.log   (re-sharded tail)
  Q125-249  -> math500_w256_sc_from125/sc_shard{0..3}.log (4-shard run)
  Q422,460,478 -> math500_w256_sc_gaps/sc_q{422,460,478}.log  (Mofe's leftovers)

NOTE: the main sc.log per dir is near-empty; the real per-question output is in
the sc_shard*.log (sharded halves) and sc_q*.log (gap run) files.

NOTE: grading in these logs is strict math_equal (✓/✗). Some ✗ are LaTeX-format
false negatives (e.g. Q422 majority {-2,1+√5,1-√5} vs gold {1±√5,-2} — same set).

STILL NEEDED for the full SC@32 table: Mofe's own SC@16 for Q250-499, and the
DeepConf 16 warm-up answers (deepconf_full500.log).

RECONSTRUCTED: Q50, 74, 78, 79, 93 were completed in an earlier Job-A run and
their voting was not retained in the final shard logs (skipped-not-logged on
relaunch). Their entries were rebuilt from the committed pkls into
  math500_w256_sc/logs/sc_reconstructed_q50_74_78_79_93.log
with the same per-trace answers, voting summary, and gt. Identical data, from pkl.
